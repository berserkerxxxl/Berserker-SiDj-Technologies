"""Reproducible, local-only assembly of pinned upstream collectors."""
import hashlib,json,shutil
from pathlib import Path

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'collectors'
OUT.mkdir(exist_ok=True)
GUARD="""// B/S Reserve modification, 2026-10-28. Upstream licenses retained.
// Runs in the extension world. Blocks mutating fetch requests.
(() => {
  const originalFetch = globalThis.fetch.bind(globalThis);
  globalThis.fetch = function(input, options) {
    const method = String((options && options.method) || (input && input.method) || 'GET').toUpperCase();
    if (method !== 'GET' && method !== 'HEAD') {
      return Promise.reject(new Error('B/S Reserve collector: only GET/HEAD requests are allowed'));
    }
    return originalFetch(input, options);
  };
})();
"""
POPUP_GUARD="""// B/S Reserve: post-export deletion is disabled.
(() => {
  function protect() {
    for (const id of ['auto-delete-after-export','auto-delete-projects','confirm-auto-delete']) {
      const input = document.getElementById(id);
      if (!input) continue;
      input.checked = false;
      Object.defineProperty(input, 'checked', {get:()=>false,set:()=>{},configurable:false});
      input.disabled = true;
      const label = input.closest('label');
      if (label) label.hidden = true;
    }
    const review=document.getElementById('btn-review');
    if(review)review.hidden=true;
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',protect);
  else protect();
})();
"""
AUTH_OLD="async function authFetch(url, attempt = 0, accountId = null, allowAccountFallback = true, fetchOptions = {}) {"
AUTH_NEW=AUTH_OLD+"""
    // B/S Reserve: also covers Firefox's pageFetch path.
    const reserveMethod=String(fetchOptions.method||'GET').toUpperCase();
    if(reserveMethod!=='GET'&&reserveMethod!=='HEAD')throw new Error('B/S Reserve collector: read-only mode');
"""
for browser in ['firefox','chromium']:
    src=ROOT/'third-party'/'chatgpt-export-upstream'
    dest=OUT/'chatgpt-export-safe'/browser
    if dest.exists():shutil.rmtree(dest)
    dest.mkdir(parents=True)
    for d in ['src','lib','popup','icons']:shutil.copytree(src/d,dest/d)
    shutil.copyfile(src/'LICENSE',dest/'LICENSE')
    manifest=json.loads((src/'manifest.json').read_text())
    manifest['name']='B/S Reserve Collector'
    manifest['version']='0.6.59.1'
    manifest['version_name']='0.6.59 + B/S Reserve read-only guard 1'
    manifest['description']='Local ChatGPT export collector. B/S Reserve edition blocks mutating requests.'
    for script in manifest['content_scripts']:script['js'].insert(0,'src/reserve-guard.js')
    if browser=='firefox':
        manifest['background']={'scripts':['src/reserve-guard.js','src/background.js']}
        gecko=manifest.setdefault('browser_specific_settings',{}).setdefault('gecko',{})
        gecko['id']='bs-reserve-collector@berserker-sidj.local'
        gecko['strict_min_version']='140.0'
        gecko['data_collection_permissions']={'required':['none']}
    else:
        manifest['background']={'service_worker':'src/background-safe.js'}
        manifest.pop('browser_specific_settings',None)
        (dest/'src'/'background-safe.js').write_text("importScripts('reserve-guard.js','background.js');\n")
    (dest/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    (dest/'src'/'reserve-guard.js').write_text(GUARD)
    content=(dest/'src'/'content.js').read_text()
    assert content.count(AUTH_OLD)==1
    (dest/'src'/'content.js').write_text(content.replace(AUTH_OLD,AUTH_NEW))
    (dest/'popup'/'reserve-popup-safe.js').write_text(POPUP_GUARD)
    p=dest/'popup'/'popup.html'
    text=p.read_text()
    assert '</body>' in text
    p.write_text(text.replace('</body>','<script src="reserve-popup-safe.js"></script></body>'))
    (dest/'BS_RESERVE_CHANGES.txt').write_text('Based on thekester/chatgpt-export commit 13568bf75688de74a5af563b20d5ccd28f4ad532.\nModified manifest, guarded fetch/authFetch, disabled auto-delete checkboxes.\nNot an official OpenAI product. Live account compatibility has not been tested.\n')

src=ROOT/'third-party'/'chatgpt-helper-upstream'
dest=OUT/'chatgpt-helper-safe'
if dest.exists():shutil.rmtree(dest)
shutil.copytree(src,dest,ignore=shutil.ignore_patterns('.git','.github','CLAUDE.md'))
manifest=json.loads((dest/'manifest.json').read_text())
manifest['name']='B/S Reserve Memory Helper'
manifest['version']='4.0.1.1'
manifest['version_name']='4.0.1 + B/S Reserve read-only guard 1'
for script in manifest['content_scripts']:script['js'].insert(0,'reserve-guard.js')
(dest/'reserve-guard.js').write_text(GUARD)
(dest/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
(dest/'BS_RESERVE_CHANGES.txt').write_text('Based on D1DX/chatgpt-helper commit 7d316cb064786207759b8d692abe4506dab459e0.\nModified manifest and added read-only fetch guard.\nLive account compatibility has not been tested.\n')

checks={str(p.relative_to(OUT)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in OUT.rglob('*') if p.is_file()}
(ROOT/'COLLECTORS_SHA256.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n')
print('Read-only collector variants assembled:',len(checks),'files')

// B/S Reserve: post-export deletion is disabled.
(() => {
  function protect() {
    for (const id of ['auto-delete-after-export','auto-delete-projects','confirm-auto-delete']) {
      const input = document.getElementById(id);
      if (!input) continue;
      input.checked = false;
      Object.defineProperty(input, 'checked', {get:()=>false,set:()=>{},configurable:false});
      input.disabled = true;
      const label = input.closest('label');
      if (label) label.hidden = true;
    }
    const review=document.getElementById('btn-review');
    if(review)review.hidden=true;
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',protect);
  else protect();
})();

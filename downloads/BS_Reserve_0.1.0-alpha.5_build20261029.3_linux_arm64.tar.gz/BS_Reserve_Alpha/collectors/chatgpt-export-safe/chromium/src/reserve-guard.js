// B/S Reserve modification, 2026-10-28. Upstream licenses retained.
// Runs in the extension world. Blocks mutating fetch requests.
(() => {
  const originalFetch = globalThis.fetch.bind(globalThis);
  globalThis.fetch = function(input, options) {
    const method = String((options && options.method) || (input && input.method) || 'GET').toUpperCase();
    if (method !== 'GET' && method !== 'HEAD') {
      return Promise.reject(new Error('B/S Reserve collector: only GET/HEAD requests are allowed'));
    }
    return originalFetch(input, options);
  };
})();

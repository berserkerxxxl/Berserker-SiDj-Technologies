package main

import (
	"errors"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"syscall"
)

func protectSecret(b []byte) ([]byte, error) {
	return nil, errors.New("сохранение ключа DPAPI доступно только в Windows")
}
func unprotectSecret(b []byte) ([]byte, error) {
	return nil, errors.New("DPAPI доступно только в Windows")
}
func hideCommand(c *exec.Cmd) {}
func openBrowser(url string)  { fmt.Println(url) }
func showError(text string)   { fmt.Fprintln(os.Stderr, text) }
func lockData(root string) (func(), error) {
	f, err := os.OpenFile(filepath.Join(root, "reserve.lock"), os.O_CREATE|os.O_RDWR, 0600)
	if err != nil {
		return nil, err
	}
	if err = syscall.Flock(int(f.Fd()), syscall.LOCK_EX|syscall.LOCK_NB); err != nil {
		f.Close()
		return nil, errors.New("данные заняты другим процессом")
	}
	return func() { syscall.Flock(int(f.Fd()), syscall.LOCK_UN); f.Close() }, nil
}
func installSchedule(exe, root string) error {
	return errors.New("расписание этого выпуска предназначено для Windows")
}
